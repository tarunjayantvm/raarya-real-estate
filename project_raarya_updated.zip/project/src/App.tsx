import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import PriceRangeFilter from './components/PriceRangeFilter';
import FeaturedProperties from './components/FeaturedProperties';
import TestimonialsSection from './components/TestimonialsSection';
import PartnersSection from './components/PartnersSection';
import Footer from './components/Footer';
import UserLogin from './components/UserLogin';
import BuyPage from './components/BuyPage';
import HomeLoansPage from './components/HomeLoansPage';
import About from './components/About';
import RentPage from './components/RentPage';
import SellPage from './components/SellPage';
import Contact from './components/Contact';

function MainSite() {
  return (
    <div className="min-h-screen bg-transparent font-lexend overflow-x-hidden">
      <Header />
      <HeroSection />
      
      {/* Price Range Filter Section */}
      <section className="py-12 bg-dark relative overflow-hidden">
        {/* Background Animation Elements */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-gold/5 rounded-full animate-float"></div>
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-gold/3 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gold mb-2 gold-shimmer animate-fade-in-up">
              Find Properties by Budget
            </h2>
            <p className="text-white animate-fade-in-up animate-delay-200">
              Set your budget range and discover properties that match your requirements
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <PriceRangeFilter />
          </div>
        </div>
      </section>
      
      <FeaturedProperties />
      <TestimonialsSection />
      <PartnersSection />
      <Footer />
    </div>
  );
}

function App() {
  useEffect(() => {
    // Add smooth scrolling behavior
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Preload critical images
    const criticalImages = [
      'https://raarya.com/wp-content/uploads/2024/06/premium-house-property-coimbatore-1.jpg',
      'https://raarya.com/wp-content/uploads/2024/07/cropped-color-logo.jpeg'
    ];
    
    criticalImages.forEach(src => {
      const img = new Image();
      img.src = src;
    });

    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <Router>
      <div className="site-bg" />
      <div className="site-bg-fade" />
      <Routes>
        <Route path="/login" element={<UserLogin />} />
        <Route path="/buy" element={<BuyPage />} />
        <Route path="/rent" element={<RentPage />} />
        <Route path="/sell" element={<SellPage />} />
        <Route path="/home-loans" element={<HomeLoansPage />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/*" element={<MainSite />} />
      </Routes>
    </Router>
  );
}

export default App;
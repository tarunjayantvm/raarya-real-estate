import React, { useState } from 'react';

const UserLogin = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      setError('Please enter your name and phone number.');
      return;
    }
    // Add your login logic here
    setError('');
    alert(`Welcome, ${name}! (Phone: ${phone})`);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-cover bg-center"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=1500&q=80')",
      }}
    >
      <form
        onSubmit={handleSubmit}
        className="bg-dark/80 rounded-xl shadow-xl p-8 w-full max-w-md flex flex-col items-center backdrop-blur-md border border-gold/20"
      >
        <h2 className="text-2xl font-bold text-gold mb-6 gold-shimmer">User Login</h2>
        {error && <div className="mb-4 text-red-400 text-sm">{error}</div>}
        <div className="w-full mb-4">
          <label className="block text-gold font-semibold mb-1">Name</label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Enter your name"
            className="w-full px-4 py-2 rounded-lg bg-dark-light text-white border border-gold/30 focus:ring-2 focus:ring-gold focus:border-transparent transition-all duration-300"
          />
        </div>
        <div className="w-full mb-6">
          <label className="block text-gold font-semibold mb-1">Phone Number</label>
          <input
            type="tel"
            value={phone}
            onChange={e => setPhone(e.target.value)}
            placeholder="Enter your phone number"
            className="w-full px-4 py-2 rounded-lg bg-dark-light text-white border border-gold/30 focus:ring-2 focus:ring-gold focus:border-transparent transition-all duration-300"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-gold text-dark font-bold py-3 rounded-lg shadow hover:bg-yellow-400 transition-all duration-300 text-lg"
        >
          Continue
        </button>
      </form>
    </div>
  );
};

export default UserLogin; 
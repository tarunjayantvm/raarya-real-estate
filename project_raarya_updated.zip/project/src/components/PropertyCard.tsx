import React, { useState } from 'react';
import { MapPin, Bed, Bath, Square, Heart, Share2, Phone, Eye } from 'lucide-react';

interface PropertyCardProps {
  id: string;
  title: string;
  location: string;
  price: string;
  type: string;
  bedrooms?: number;
  bathrooms?: number;
  area: string;
  image: string;
  isForSale: boolean;
}

const PropertyCard: React.FC<PropertyCardProps> = ({
  id,
  title,
  location,
  price,
  type,
  bedrooms,
  bathrooms,
  area,
  image,
  isForSale
}) => {
  const [isLiked, setIsLiked] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleViewProperty = () => {
    window.location.href = `/property/${id}`;
  };

  const handleContact = () => {
    window.location.href = `/contact?property=${id}`;
  };

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLiked(!isLiked);
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.share) {
      navigator.share({
        title: title,
        text: `Check out this property: ${title}`,
        url: window.location.href
      });
    }
  };

  return (
    <div className="premium-card rounded-xl overflow-hidden shadow-premium hover:shadow-premium-lg group cursor-pointer">
      {/* Property Image */}
      <div className="relative overflow-hidden">
        <div className={`w-full h-48 bg-dark-light transition-all duration-500 ${imageLoaded ? '' : 'loading-shimmer'}`}>
          <img 
            src={image} 
            alt={title}
            className={`w-full h-full object-cover transition-all duration-700 group-hover:scale-110 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setImageLoaded(true)}
          />
        </div>
        
        {/* Overlay with animations */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
        
        {/* Status Badge */}
        <div className="absolute top-4 left-4 animate-fade-in-left">
          <span className={`px-3 py-1 rounded-full text-xs font-bold backdrop-blur-sm transition-all duration-300 ${
            isForSale 
              ? 'bg-gold/90 text-dark shadow-lg' 
              : 'bg-green-500/90 text-white shadow-lg'
          }`}>
            {isForSale ? 'For Sale' : 'For Rent'}
          </span>
        </div>
        
        {/* Action Buttons */}
        <div className="absolute top-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-all duration-300 animate-fade-in-right">
          <button 
            onClick={handleLike}
            className={`backdrop-blur-sm p-2 rounded-full transition-all duration-300 transform hover:scale-110 ${
              isLiked 
                ? 'bg-red-500/90 text-white' 
                : 'bg-black/50 text-white hover:bg-gold hover:text-dark'
            }`}
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
          </button>
          <button 
            onClick={handleShare}
            className="backdrop-blur-sm bg-black/50 text-white p-2 rounded-full hover:bg-gold hover:text-dark transition-all duration-300 transform hover:scale-110"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

        {/* View Count */}
        <div className="absolute bottom-4 right-4 flex items-center space-x-1 bg-black/50 backdrop-blur-sm px-2 py-1 rounded-full text-white text-xs opacity-0 group-hover:opacity-100 transition-all duration-300">
          <Eye className="w-3 h-3" />
          <span>{Math.floor(Math.random() * 100) + 50}</span>
        </div>
      </div>
      
      {/* Property Details */}
      <div className="p-6">
        <h3 className="text-gold text-lg font-bold mb-2 line-clamp-2 group-hover:text-gold-light transition-colors duration-300">
          {title}
        </h3>
        
        <div className="flex items-center text-white text-sm mb-3 group-hover:text-gold-light transition-colors duration-300">
          <MapPin className="w-4 h-4 mr-1 animate-pulse-slow" />
          <span>{location}</span>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <div className="text-gold-light text-xl font-bold animate-pulse-slow">{price}</div>
          <div className="text-white text-sm bg-dark-light px-3 py-1 rounded-full border border-gold/20">
            {type}
          </div>
        </div>
        
        {/* Property Features */}
        <div className="flex items-center justify-between text-white text-sm mb-4">
          {bedrooms && (
            <div className="flex items-center group/feature">
              <Bed className="w-4 h-4 mr-1 group-hover/feature:text-gold transition-colors duration-300" />
              <span>{bedrooms} Bed</span>
            </div>
          )}
          {bathrooms && (
            <div className="flex items-center group/feature">
              <Bath className="w-4 h-4 mr-1 group-hover/feature:text-gold transition-colors duration-300" />
              <span>{bathrooms} Bath</span>
            </div>
          )}
          <div className="flex items-center group/feature">
            <Square className="w-4 h-4 mr-1 group-hover/feature:text-gold transition-colors duration-300" />
            <span>{area}</span>
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="flex space-x-3">
          <button
            onClick={handleViewProperty}
            className="flex-1 premium-button text-dark font-bold py-2 px-4 rounded-lg"
          >
            View Details
          </button>
          <button
            onClick={handleContact}
            className="bg-dark-light text-gold border border-gold font-bold py-2 px-4 rounded-lg hover:bg-gold hover:text-dark transition-all duration-300 flex items-center transform hover:scale-105"
          >
            <Phone className="w-4 h-4 mr-1" />
            Call
          </button>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
import React, { useState } from 'react';
import Header from './Header';
import Footer from './Footer';
import { Heart, Plus, ExternalLink, BedDouble, Bath, Ruler, ListChecks, Info } from 'lucide-react';
import { useLocation } from 'react-router-dom';

// Example property data (replace with your real data)
const allProperties = [
  // PAGE 1
  {
    id: 1,
    title: '3 BHK Apartment in RS Puram',
    location: 'RS Puram, Coimbatore, Tamil Nadu, India',
    price: 8500000,
    area: 1450,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1588880331179-682d53ae396c?w=800&q=80',
    hotOffer: true,
    bedrooms: 3,
    bathrooms: 2,
    status: 'Ready to Move',
    description: 'Spacious 3BHK apartment with modern amenities and city views.'
  },
  {
    id: 2,
    title: '2 BHK Flat for Rent in Gandhipuram',
    location: 'Gandhipuram, Coimbatore, Tamil Nadu, India',
    price: 16000,
    area: 900,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1467987506553-8f3916508521?w=800&q=80',
    hotOffer: false,
    bedrooms: 2,
    bathrooms: 2,
    status: 'Available',
    description: 'Well-lit 2BHK flat, close to shopping and transport.'
  },
  {
    id: 3,
    title: 'Luxury Villa in Saibaba Colony',
    location: 'Saibaba Colony, Coimbatore, Tamil Nadu, India',
    price: 22000000,
    area: 3200,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?w=800&q=80',
    hotOffer: true,
    bedrooms: 4,
    bathrooms: 4,
    status: 'Ready to Move',
    description: 'Premium villa with private garden and pool.'
  },
  {
    id: 4,
    title: '1 BHK House for Rent in Peelamedu',
    location: 'Peelamedu, Coimbatore, Tamil Nadu, India',
    price: 9000,
    area: 600,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?w=800&q=80',
    hotOffer: false,
    bedrooms: 1,
    bathrooms: 1,
    status: 'Available',
    description: 'Cozy 1BHK house in a peaceful neighborhood.'
  },
  {
    id: 5,
    title: 'Commercial Office Space in Avinashi Road',
    location: 'Avinashi Road, Coimbatore, Tamil Nadu, India',
    price: 18000000,
    area: 3500,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1503389152951-9c3d029fd6a0?w=800&q=80',
    hotOffer: true,
    bedrooms: 0,
    bathrooms: 2,
    status: 'Available',
    description: 'Premium office space in a landmark building.'
  },
  {
    id: 6,
    title: 'Studio Apartment for Rent in Town Hall',
    location: 'Town Hall, Coimbatore, Tamil Nadu, India',
    price: 7000,
    area: 350,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?w=800&q=80',
    hotOffer: false,
    bedrooms: 1,
    bathrooms: 1,
    status: 'Available',
    description: 'Affordable studio apartment, ideal for singles.'
  },
  {
    id: 7,
    title: '4 BHK Villa in Saravanampatti',
    location: 'Saravanampatti, Coimbatore, Tamil Nadu, India',
    price: 32000000,
    area: 4100,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?w=800&q=80',
    hotOffer: false,
    bedrooms: 4,
    bathrooms: 5,
    status: 'Ready to Move',
    description: 'Luxury villa with garden, pool, and smart home features.'
  },
  {
    id: 8,
    title: '2 BHK Flat for Rent in Singanallur',
    location: 'Singanallur, Coimbatore, Tamil Nadu, India',
    price: 14000,
    area: 850,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800&q=80',
    hotOffer: false,
    bedrooms: 2,
    bathrooms: 2,
    status: 'Available',
    description: 'Modern 2BHK flat with amenities and parking.'
  },
  {
    id: 9,
    title: 'Plot for Sale in Vadavalli',
    location: 'Vadavalli, Coimbatore, Tamil Nadu, India',
    price: 1200000,
    area: 2400,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?w=800&q=80',
    hotOffer: false,
    bedrooms: 0,
    bathrooms: 0,
    status: 'Available',
    description: 'Residential plot in a prime location.'
  },
  // PAGE 2
  {
    id: 10,
    title: '3 BHK Apartment in Kalapatti',
    location: 'Kalapatti, Coimbatore, Tamil Nadu, India',
    price: 7800000,
    area: 1300,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
    hotOffer: false,
    bedrooms: 3,
    bathrooms: 2,
    status: 'Ready to Move',
    description: 'Newly built 3BHK apartment with clubhouse access.'
  },
  {
    id: 11,
    title: '1 BHK Flat for Rent in Kovaipudur',
    location: 'Kovaipudur, Coimbatore, Tamil Nadu, India',
    price: 8000,
    area: 500,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',
    hotOffer: false,
    bedrooms: 1,
    bathrooms: 1,
    status: 'Available',
    description: 'Bright 1BHK flat with balcony and green views.'
  },
  {
    id: 12,
    title: 'Commercial Shop in Town Hall',
    location: 'Town Hall, Coimbatore, Tamil Nadu, India',
    price: 3500000,
    area: 600,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1503389152951-9c3d029fd6a0?w=800&q=80',
    hotOffer: false,
    bedrooms: 0,
    bathrooms: 1,
    status: 'Available',
    description: 'Shop space in a high-footfall commercial area.'
  },
  {
    id: 13,
    title: '2 BHK House for Rent in Ramanathapuram',
    location: 'Ramanathapuram, Coimbatore, Tamil Nadu, India',
    price: 12000,
    area: 750,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80',
    hotOffer: false,
    bedrooms: 2,
    bathrooms: 2,
    status: 'Available',
    description: 'Independent 2BHK house with car parking.'
  },
  {
    id: 14,
    title: 'Luxury Penthouse in Race Course',
    location: 'Race Course, Coimbatore, Tamil Nadu, India',
    price: 65000000,
    area: 3500,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&q=80',
    hotOffer: true,
    bedrooms: 5,
    bathrooms: 5,
    status: 'Ready to Move',
    description: 'Stunning penthouse with panoramic city views.'
  },
  {
    id: 15,
    title: 'Studio Apartment for Rent in Ukkadam',
    location: 'Ukkadam, Coimbatore, Tamil Nadu, India',
    price: 6000,
    area: 320,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1595526114035-0d45ed16433d?w=800&q=80',
    hotOffer: false,
    bedrooms: 1,
    bathrooms: 1,
    status: 'Available',
    description: 'Compact studio apartment, ideal for students.'
  },
  {
    id: 16,
    title: 'Farm House for Sale in Karamadai',
    location: 'Karamadai, Coimbatore, Tamil Nadu, India',
    price: 4200000,
    area: 5000,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800&q=80',
    hotOffer: false,
    bedrooms: 2,
    bathrooms: 2,
    status: 'Available',
    description: 'Farm house with land and water source.'
  },
  {
    id: 17,
    title: '3 BHK Flat for Rent in Neelambur',
    location: 'Neelambur, Coimbatore, Tamil Nadu, India',
    price: 18000,
    area: 1200,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
    hotOffer: false,
    bedrooms: 3,
    bathrooms: 2,
    status: 'Available',
    description: 'Spacious 3BHK flat with all amenities.'
  },
  {
    id: 18,
    title: 'Warehouse for Sale in Podanur',
    location: 'Podanur, Coimbatore, Tamil Nadu, India',
    price: 9000000,
    area: 6000,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',
    hotOffer: false,
    bedrooms: 0,
    bathrooms: 1,
    status: 'Available',
    description: 'Large warehouse with easy access to highways.'
  },
  // PAGE 3
  {
    id: 19,
    title: '2 BHK Apartment in Thudiyalur',
    location: 'Thudiyalur, Coimbatore, Tamil Nadu, India',
    price: 5200000,
    area: 1100,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80',
    hotOffer: false,
    bedrooms: 2,
    bathrooms: 2,
    status: 'Ready to Move',
    description: 'Modern 2BHK apartment in a gated community.'
  },
  {
    id: 20,
    title: '1 BHK Flat for Rent in Kuniyamuthur',
    location: 'Kuniyamuthur, Coimbatore, Tamil Nadu, India',
    price: 7500,
    area: 480,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&q=80',
    hotOffer: false,
    bedrooms: 1,
    bathrooms: 1,
    status: 'Available',
    description: 'Affordable 1BHK flat with good connectivity.'
  },
  {
    id: 21,
    title: 'Shop for Sale in Eachanari',
    location: 'Eachanari, Coimbatore, Tamil Nadu, India',
    price: 2800000,
    area: 400,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
    hotOffer: false,
    bedrooms: 0,
    bathrooms: 1,
    status: 'Available',
    description: 'Commercial shop in a busy market area.'
  },
  {
    id: 22,
    title: '2 BHK House for Rent in Chinnavedampatti',
    location: 'Chinnavedampatti, Coimbatore, Tamil Nadu, India',
    price: 11000,
    area: 700,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800&q=80',
    hotOffer: false,
    bedrooms: 2,
    bathrooms: 2,
    status: 'Available',
    description: '2BHK independent house with parking.'
  },
  {
    id: 23,
    title: 'Warehouse for Sale in Neelambur',
    location: 'Neelambur, Coimbatore, Tamil Nadu, India',
    price: 12000000,
    area: 8000,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',
    hotOffer: false,
    bedrooms: 0,
    bathrooms: 1,
    status: 'Available',
    description: 'Spacious warehouse with loading dock.'
  },
  {
    id: 24,
    title: '3 BHK Flat for Rent in Kovaipudur',
    location: 'Kovaipudur, Coimbatore, Tamil Nadu, India',
    price: 17000,
    area: 1150,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
    hotOffer: false,
    bedrooms: 3,
    bathrooms: 2,
    status: 'Available',
    description: '3BHK flat with modern interiors and amenities.'
  },
  {
    id: 25,
    title: 'Farm House for Sale in Vadavalli',
    location: 'Vadavalli, Coimbatore, Tamil Nadu, India',
    price: 6500000,
    area: 3500,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800&q=80',
    hotOffer: false,
    bedrooms: 3,
    bathrooms: 2,
    status: 'Available',
    description: 'Farm house with scenic views and fruit trees.'
  },
  {
    id: 26,
    title: 'Studio Apartment for Rent in Podanur',
    location: 'Podanur, Coimbatore, Tamil Nadu, India',
    price: 6500,
    area: 300,
    type: 'rent',
    image: 'https://images.unsplash.com/photo-1595526114035-0d45ed16433d?w=800&q=80',
    hotOffer: false,
    bedrooms: 1,
    bathrooms: 1,
    status: 'Available',
    description: 'Studio apartment, close to railway station.'
  },
  {
    id: 27,
    title: 'Commercial Office Space in Gandhipuram',
    location: 'Gandhipuram, Coimbatore, Tamil Nadu, India',
    price: 15000000,
    area: 3000,
    type: 'buy',
    image: 'https://images.unsplash.com/photo-1503389152951-9c3d029fd6a0?w=800&q=80',
    hotOffer: false,
    bedrooms: 0,
    bathrooms: 2,
    status: 'Available',
    description: 'Office space in a prime business district.'
  },
];

const filters = [
  { label: 'ALL', value: 'all', color: 'bg-gold text-dark' },
  { label: 'FOR BUY', value: 'buy', color: 'bg-gold text-dark' },
  { label: 'FOR RENT', value: 'rent', color: 'bg-gold text-dark' },
];

const sortOptions = [
  { label: 'Default Order', value: 'default' },
  { label: 'Price: Low to High', value: 'priceLow' },
  { label: 'Price: High to Low', value: 'priceHigh' },
];

const PAGE_SIZE = 9;

function filterProperties(properties: any[], filter: any) {
  if (filter === 'buy') return properties.filter((p: any) => p.type === 'buy');
  if (filter === 'rent') return properties.filter((p: any) => p.type === 'rent');
  return properties;
}

function sortProperties(properties: any[], sort: any) {
  if (sort === 'priceLow') return [...properties].sort((a: any, b: any) => a.price - b.price);
  if (sort === 'priceHigh') return [...properties].sort((a: any, b: any) => b.price - a.price);
  return properties;
}

// Helper for type-safe property access
function getFieldValue(obj: any, key: string) {
  switch (key) {
    case 'image': return obj.image;
    case 'title': return obj.title;
    case 'price': return obj.price;
    case 'area': return obj.area;
    case 'bedrooms': return obj.bedrooms;
    case 'bathrooms': return obj.bathrooms;
    case 'status': return obj.status;
    case 'amenities': return obj.amenities;
    case 'type': return obj.type;
    case 'location': return obj.location;
    case 'description': return obj.description;
    default: return '';
  }
}

// Animation classes for modal
const modalAnim = 'animate-[popIn_0.35s_ease]';
// Gold shimmer animation for modal border (add to global CSS if not present)
const shimmerAnim = 'animate-[shimmer_2s_linear_infinite]';

export default function PropertiesPage() {
  const [filter, setFilter] = React.useState('all');
  const [sort, setSort] = React.useState('default');
  const [page, setPage] = React.useState(1);
  const [wishlist, setWishlist] = React.useState<number[]>([]);
  const [compare, setCompare] = React.useState<number[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  const locationRouter = useLocation();
  // Parse query params
  const params = React.useMemo(() => {
    const searchParams = new URLSearchParams(locationRouter.search);
    return {
      tab: searchParams.get('tab') || 'Buy',
      location: searchParams.get('location') || '',
      type: searchParams.get('type') || '',
      budget: searchParams.get('budget') || '',
      q: searchParams.get('q') || '',
    };
  }, [locationRouter.search]);

  // Filter properties based on params
  const filterByParams = (properties: any[]) => {
    let filtered = [...properties];
    // Tab (Buy/Rent/Projects)
    if (params.tab === 'Buy') filtered = filtered.filter(p => p.type === 'buy' || p.type === 'Buy');
    if (params.tab === 'Rent') filtered = filtered.filter(p => p.type === 'rent' || p.type === 'Rent');
    // Location
    if (params.location) filtered = filtered.filter(p => (p.location || '').toLowerCase().includes(params.location.toLowerCase()));
    // Type
    if (params.type) filtered = filtered.filter(p => (p.title || '').toLowerCase().includes(params.type.toLowerCase()) || (p.type || '').toLowerCase().includes(params.type.toLowerCase()));
    // Budget
    if (params.budget) {
      if (params.budget === '10-20') filtered = filtered.filter(p => p.price >= 1000000 && p.price <= 2000000);
      if (params.budget === '20-50') filtered = filtered.filter(p => p.price > 2000000 && p.price <= 5000000);
      if (params.budget === '50-100') filtered = filtered.filter(p => p.price > 5000000 && p.price <= 10000000);
      if (params.budget === '100-200') filtered = filtered.filter(p => p.price > 10000000 && p.price <= 20000000);
      if (params.budget === '200+') filtered = filtered.filter(p => p.price > 20000000);
    }
    // Search query
    if (params.q) {
      filtered = filtered.filter(p =>
        (p.title && p.title.toLowerCase().includes(params.q.toLowerCase())) ||
        (p.location && p.location.toLowerCase().includes(params.q.toLowerCase())) ||
        (p.description && p.description.toLowerCase().includes(params.q.toLowerCase()))
      );
    }
    return filtered;
  };

  const filteredByParams = filterByParams(allProperties);
  const filtered = filterProperties(filteredByParams, filter);
  const sorted = sortProperties(filtered, sort);
  const totalPages = Math.ceil(sorted.length / PAGE_SIZE);
  const paginated = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // Get compared properties
  const comparedProperties = allProperties.filter(p => compare.includes(p.id));

  // Helper to get all keys to compare
  const compareFields = [
    { key: 'image', label: '', icon: null },
    { key: 'title', label: 'Title', icon: <Info className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'price', label: 'Price', icon: <Info className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'area', label: 'Area', icon: <Ruler className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'bedrooms', label: 'Bedrooms', icon: <BedDouble className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'bathrooms', label: 'Bathrooms', icon: <Bath className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'status', label: 'Status', icon: <Info className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'amenities', label: 'Amenities', icon: <ListChecks className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'type', label: 'Type', icon: <Info className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'location', label: 'Location', icon: <Info className="inline w-5 h-5 mr-1 text-gold" /> },
    { key: 'description', label: 'Description', icon: <Info className="inline w-5 h-5 mr-1 text-gold" /> },
  ];

  // Helper to check if all values in a field are the same
  const isSame = (field: string) => {
    if (comparedProperties.length < 2) return true;
    const first = getFieldValue(comparedProperties[0], field);
    return comparedProperties.every(p => {
      const val = getFieldValue(p, field);
      if (Array.isArray(first) && Array.isArray(val)) {
        return JSON.stringify(first) === JSON.stringify(val);
      }
      return val === first;
    });
  };

  const handleExternalLink = (property: any) => {
    window.open('https://raarya.com', '_blank'); // Placeholder, replace with property details link if available
  };
  const handleWishlist = (id: number) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(pid => pid !== id) : [...prev, id]);
  };
  const handleCompare = (id: number) => {
    setCompare(prev => prev.includes(id) ? prev.filter(pid => pid !== id) : [...prev, id]);
  };

  return (
    <>
      <Header />
      <div className="bg-dark min-h-screen pt-32 pb-16">
        {/* Filter & Sort Bar */}
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4 px-4 mb-8">
          <div className="flex gap-4">
            {filters.map(f => (
              <button
                key={f.value}
                className={`px-6 py-2 font-bold text-base rounded-full shadow ${filter === f.value ? 'bg-gold text-dark' : 'bg-dark-light text-gold border border-gold'} transition`}
                onClick={() => setFilter(f.value)}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-lg font-semibold text-gold">Sort By:</span>
            <select
              className="bg-dark-light text-gold border border-gold px-4 py-2 rounded shadow focus:outline-none"
              value={sort}
              onChange={e => setSort(e.target.value)}
            >
              {sortOptions.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Property Cards Grid */}
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-2">
          {paginated.map((property: any) => (
            <div
              key={property.id}
              className="bg-dark-light rounded-xl shadow-lg overflow-hidden flex flex-col border border-gold/10 transition-transform duration-200 hover:-translate-y-1 hover:shadow-gold/30 hover:shadow-xl group w-full max-w-md mx-auto"
              style={{ boxShadow: '0 2px 12px 0 rgba(212,180,84,0.06)' }}
            >
              <div className="relative">
                <img src={property.image} alt={property.title} className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300" />
                {property.hotOffer && (
                  <span className="absolute top-3 right-3 bg-gold text-dark text-xs font-bold px-3 py-1 rounded shadow">HOT OFFER</span>
                )}
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className={`px-3 py-1 text-xs font-bold rounded-full border border-gold bg-dark-light text-gold shadow`}>{property.type.toUpperCase()}</span>
                </div>
                <div className="absolute bottom-3 left-3 flex gap-2">
                  {/* External Link (inactive) */}
                  <button
                    className="bg-gold text-dark p-2 rounded-full border border-gold opacity-50 cursor-not-allowed focus:outline-none"
                    disabled
                    title="View Details (coming soon)"
                  >
                    <ExternalLink size={18} />
                  </button>
                  {/* Wishlist */}
                  <button
                    className={`p-2 rounded-full border border-gold transition focus:outline-none ${wishlist.includes(property.id) ? 'bg-dark text-gold' : 'bg-gold text-dark hover:bg-gold-dark'}`}
                    onClick={() => handleWishlist(property.id)}
                    title={wishlist.includes(property.id) ? 'Remove from Wishlist' : 'Add to Wishlist'}
                  >
                    <Heart size={18} fill={wishlist.includes(property.id) ? '#d4b454' : 'none'} />
                  </button>
                  {/* Compare */}
                  <button
                    className={`p-2 rounded-full border border-gold transition focus:outline-none ${compare.includes(property.id) ? 'bg-dark text-gold ring-2 ring-gold' : 'bg-gold text-dark hover:bg-gold-dark'}`}
                    onClick={() => handleCompare(property.id)}
                    title={compare.includes(property.id) ? 'Remove from Compare' : 'Add to Compare'}
                  >
                    <Plus size={18} />
                  </button>
                </div>
              </div>
              <div className="p-4 flex-1 flex flex-col gap-1">
                <div className="flex items-center justify-between mb-1">
                  <div className="text-2xl font-extrabold text-gold">₹{property.price.toLocaleString()}</div>
                  <span className={`px-2 py-1 text-xs font-bold rounded border border-gold bg-dark-light text-gold`}>{property.status}</span>
                </div>
                <div className="font-extrabold text-lg text-white mb-0.5 leading-tight">{property.title}</div>
                <div className="text-gray-400 text-sm mb-1">{property.location}</div>
                <div className="flex items-center gap-3 text-gold text-sm mb-1">
                  <svg className="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 21V7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v14" /></svg>
                  <span className="font-semibold">{property.area} sqft</span>
                  <span className="text-gold/80">|</span>
                  <span className="font-semibold">{property.bedrooms} Bed</span>
                  <span className="font-semibold">{property.bathrooms} Bath</span>
                </div>
                <div className="text-xs text-gold/80 mb-1">{property.type.toUpperCase()}</div>
                <div className="text-gray-300 text-xs mb-2 line-clamp-2">{property.description}</div>
                {/* Subtle divider */}
                <div className="border-t border-gold/20 my-2"></div>
              </div>
              <button className="bg-gold text-dark font-bold py-3 text-lg w-full rounded-none hover:bg-gold-dark transition border-t border-gold/20">Details</button>
            </div>
          ))}
        </div>
        {/* Pagination Bar */}
        <div className="flex justify-center mt-12 gap-2">
          <button
            className={`w-12 h-12 flex items-center justify-center text-2xl font-bold rounded-lg border border-gold bg-dark text-gold hover:bg-gold/20 transition disabled:opacity-40`}
            onClick={() => setPage(1)}
            disabled={page === 1}
            aria-label="First page"
          >
            &laquo;
          </button>
          <button
            className={`w-12 h-12 flex items-center justify-center text-2xl font-bold rounded-lg border border-gold bg-dark text-gold hover:bg-gold/20 transition disabled:opacity-40`}
            onClick={() => setPage(page - 1)}
            disabled={page === 1}
            aria-label="Previous page"
          >
            &lsaquo;
          </button>
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i + 1}
              className={`w-12 h-12 flex items-center justify-center text-xl font-bold rounded-lg border border-gold transition
                ${page === i + 1 ? 'bg-gold text-dark' : 'bg-dark text-gold hover:bg-gold/20'}`}
              onClick={() => setPage(i + 1)}
            >
              {i + 1}
            </button>
          ))}
          <button
            className={`w-12 h-12 flex items-center justify-center text-2xl font-bold rounded-lg border border-gold bg-dark text-gold hover:bg-gold/20 transition disabled:opacity-40`}
            onClick={() => setPage(page + 1)}
            disabled={page === totalPages}
            aria-label="Next page"
          >
            &rsaquo;
          </button>
          <button
            className={`w-12 h-12 flex items-center justify-center text-2xl font-bold rounded-lg border border-gold bg-dark text-gold hover:bg-gold/20 transition disabled:opacity-40`}
            onClick={() => setPage(totalPages)}
            disabled={page === totalPages}
            aria-label="Last page"
          >
            &raquo;
          </button>
        </div>
        {/* Sticky Compare Bar */}
        {compare.length >= 2 && (
          <div className="fixed bottom-0 left-0 w-full z-50 flex justify-center items-center bg-dark/95 border-t border-gold/30 py-4 shadow-2xl animate-fade-in-up">
            <div className="flex gap-2">
              {comparedProperties.map(p => (
                <div key={p.id} className="flex items-center gap-2 bg-dark-light border border-gold/30 rounded-full px-4 py-2 text-gold font-bold shadow">
                  <img src={p.image} alt={p.title} className="w-8 h-8 rounded-full object-cover border border-gold" />
                  <span className="truncate max-w-[120px]">{p.title}</span>
                  <button onClick={() => setCompare(compare.filter(id => id !== p.id))} className="ml-1 text-gold hover:text-red-500 font-bold">×</button>
                </div>
              ))}
            </div>
            <button
              className="ml-6 px-8 py-3 bg-gold text-dark font-bold rounded-full shadow-lg hover:bg-gold/90 transition text-lg border-2 border-gold focus:outline-none"
              onClick={() => setShowCompareModal(true)}
            >
              Compare
            </button>
          </div>
        )}
        {/* Compare Modal */}
        {showCompareModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
            <div className={`relative bg-gradient-to-br from-[#18140f] via-[#23201a] to-[#18140f] rounded-3xl shadow-2xl max-w-7xl w-full mx-2 my-8 overflow-x-auto overflow-y-auto max-h-[95vh] border-4 border-gold/80 animate-[popIn_0.35s_ease] animate-[shimmer_2s_linear_infinite]`}
              style={{ boxShadow: '0 8px 48px 0 rgba(212,180,84,0.18)' }}>
              {/* Sticky header */}
              <div className="sticky top-0 z-10 flex items-center justify-between px-10 py-6 bg-dark/95 rounded-t-3xl border-b-2 border-gold/40 shadow-lg">
                <h2 className="text-3xl font-extrabold text-gold tracking-wide text-center w-full">Compare Properties</h2>
                <button
                  className="absolute top-4 right-6 flex items-center justify-center w-14 h-14 bg-gold text-dark rounded-full border-4 border-gold shadow-xl hover:shadow-gold/60 hover:scale-110 hover:rotate-12 transition-all duration-200 text-3xl font-extrabold focus:outline-none"
                  onClick={() => setShowCompareModal(false)}
                  title="Close"
                  style={{ lineHeight: 1 }}
                >
                  <span className="block" style={{ fontFamily: 'inherit', fontWeight: 900, fontSize: '2.2rem', marginTop: '-2px' }}>×</span>
                </button>
              </div>
              <div className="p-10 pt-4 bg-dark-light/80 rounded-b-3xl">
                <div className="overflow-x-auto">
                  <table className="min-w-full align-middle">
                    <thead>
                      <tr>
                        <th className="w-56"></th>
                        {comparedProperties.map((p, idx) => (
                          <th key={p.id} className="text-center align-top px-8 pb-6">
                            <div className="flex flex-col items-center gap-3">
                              <img src={p.image} alt={p.title} className="w-28 h-24 object-cover rounded-xl border-2 border-gold shadow-md" />
                              <div className="text-lg font-extrabold text-gold text-center leading-tight truncate w-48" title={p.title}>{p.title}</div>
                            </div>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {compareFields.filter(f => f.key !== 'image').map(field => (
                        <tr key={field.key}>
                          <td className="py-5 pr-8 text-gold font-bold align-middle whitespace-nowrap text-lg flex items-center gap-2">
                            <span className="inline-block">{field.icon}</span>
                            <span>{field.label}</span>
                          </td>
                          {comparedProperties.map((p, idx) => {
                            let value = getFieldValue(p, field.key);
                            if (field.key === 'amenities' && Array.isArray(value)) {
                              value = value.length ? value.map((a: string, i: number) => (
                                <span key={i} className="inline-block bg-gold/90 text-dark font-semibold rounded-full px-4 py-2 mx-1 my-0.5 text-base shadow">{a}</span>
                              )) : <span className="text-gold/40">—</span>;
                            }
                            if (field.key === 'status') {
                              value = value ? <span className="inline-block bg-gold text-dark font-bold rounded-full px-6 py-2 text-base shadow border border-gold/80">{value}</span> : <span className="text-gold/40">—</span>;
                            }
                            if (field.key === 'price' || field.key === 'area') {
                              value = value ? <span className="inline-block bg-gold/80 text-dark font-bold rounded-lg px-6 py-2 text-lg shadow border border-gold/80">{value}</span> : <span className="text-gold/40">—</span>;
                            }
                            if (field.key === 'description') {
                              value = value ? <span className="text-base text-gray-300 font-medium">{value}</span> : <span className="text-gold/40">—</span>;
                            }
                            // Highlight differences
                            const highlight = !isSame(field.key);
                            return (
                              <td
                                key={field.key}
                                className={`px-4 py-4 align-middle transition-all duration-300 ${highlight ? 'border-2 border-gold shadow-lg' : 'border-2 border-gold/30'} bg-dark rounded-xl text-gold font-semibold text-lg min-w-[180px] max-w-[340px] whitespace-pre-line`}
                                tabIndex={0}
                                title={highlight ? 'This value is different' : 'This value is the same'}
                              >
                                <span className="flex flex-wrap items-center justify-center gap-2">{value || <span className="text-gold/40">—</span>}</span>
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
} 